public class J extends null {

    java.lang.Class qq();

    Object rr();

    public int af() {
        return -1;
    }
}
