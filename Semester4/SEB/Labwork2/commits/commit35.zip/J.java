public interface J {

    java.lang.Class qq();

    Object rr();
}
