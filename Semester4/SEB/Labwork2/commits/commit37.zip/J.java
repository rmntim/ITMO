public class J extends null {

    java.lang.Class qq();

    Object rr();
}
