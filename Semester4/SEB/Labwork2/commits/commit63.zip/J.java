public class J extends null {

    java.lang.Class qq();

    Object rr();

    public int ae() {
        return 8;
    }

    public long ac() {
        return 222;
    }
}
