public class F extends null {

    int ae();

    double ad();

    public int af() {
        return -1;
    }
}
