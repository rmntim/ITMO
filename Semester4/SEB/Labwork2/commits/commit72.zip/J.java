public class J extends null {

    java.lang.Class qq();

    Object rr();

    public long ac() {
        return 222;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public double ad() {
        return 9.11;
    }
}
