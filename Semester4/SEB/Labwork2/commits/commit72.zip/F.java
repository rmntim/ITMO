public class F extends null {

    int ae();

    double ad();

    public int cc() {
        return 13;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public void aa() {
        System.out.println("void aa");
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
