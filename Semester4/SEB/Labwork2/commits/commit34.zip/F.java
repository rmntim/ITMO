public class F extends null {

    int ae();

    double ad();
}
