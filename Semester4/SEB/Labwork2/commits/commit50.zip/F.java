public interface F {

    int ae();

    double ad();
}
