public class F extends null {

    int ae();

    double ad();

    public int cc() {
        return 13;
    }
}
