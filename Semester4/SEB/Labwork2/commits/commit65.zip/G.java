public class G extends null implements F, J {

    private byte i = 1;

    private int a = 1;

    public int cc() {
        return 42;
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public double ad() {
        return 12.12;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public Object rr() {
        return null;
    }

    public float ff() {
        return 0;
    }

    public int af() {
        return -1;
    }

    public Object pp() {
        return this;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }
}
