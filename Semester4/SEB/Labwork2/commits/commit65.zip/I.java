public class I extends G {

    private double f = 100.500;

    private double b = 100.500;

    public float ff() {
        return 0;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public long dd() {
        return 99999;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public long ac() {
        return 111;
    }

    public double ee() {
        return 500.100;
    }
}
